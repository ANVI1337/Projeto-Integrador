const fecharPagina = document.getElementById('botaoSair');

fecharPagina.addEventListener('click', function () {
    window.close();
})